package org.mmocore.xmlrpcserver;

import org.apache.xmlrpc.XmlRpcRequest;
import org.apache.xmlrpc.common.XmlRpcHttpRequestConfig;
import org.apache.xmlrpc.server.AbstractReflectiveHandlerMapping;
import org.mmocore.gameserver.Config;
import java.net.InetAddress;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.WebServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XMLRPCServer
{
	private static XMLRPCServer _instance = null;
	private static Logger _log = LoggerFactory.getLogger(XMLRPCServer.class);
	private WebServer _webServer;

	private XMLRPCServer()
	{
		try
		{
			InetAddress host = InetAddress.getByName("0.0.0.0");
			_webServer = new WebServer(Config.XML_RPC_PORT, host);
			XmlRpcServer xmlServer = _webServer.getXmlRpcServer();
			PropertyHandlerMapping phm = new PropertyHandlerMapping();
			xmlServer.setHandlerMapping(phm);
			XmlRpcServerConfigImpl serverConfig = (XmlRpcServerConfigImpl) xmlServer.getConfig();
			AbstractReflectiveHandlerMapping.AuthenticationHandler handler = new AbstractReflectiveHandlerMapping.AuthenticationHandler(){
				public boolean isAuthorized(XmlRpcRequest pRequest){
					XmlRpcHttpRequestConfig config = (XmlRpcHttpRequestConfig) pRequest.getConfig();
					return isAuthenticated(config.getBasicUserName(), config.getBasicPassword());
				};
			};
			phm.setAuthenticationHandler(handler);

			try
			{
				Class<?> clazzWorldService = Class.forName("org.mmocore.xmlrpcserver.XMLServices.WorldService");
				if(clazzWorldService != null)
				{
					phm.addHandler("WorldService", clazzWorldService);
					_log.info("XMLRPCServer: Registered " + clazzWorldService.getSimpleName() + " service with " + clazzWorldService.getMethods().length + " method(s).");
				}

				Class<?> clazzPlayerService = Class.forName("org.mmocore.xmlrpcserver.XMLServices.PlayerService");
				if(clazzPlayerService != null)
				{
					phm.addHandler("PlayerService", clazzPlayerService);
					_log.info("XMLRPCServer: Registered " + clazzPlayerService.getSimpleName() + " service with " + clazzPlayerService.getMethods().length + " method(s).");
				}


			}
			catch(ClassNotFoundException e)
			{
				_log.error("XMLRPCServer: Error while injection in service class!", e);
			}

			if(phm.getListMethods().length > 0)
			{
				serverConfig.setEnabledForExtensions(true);
				serverConfig.setContentLengthOptional(false);
				_webServer.start();
				_log.info("XMLRPCServer: Started. Listen on " + host.getHostAddress() + ":" + Config.XML_RPC_PORT);
			}
			else
			{
				_log.info("XMLRPCServer: Disabled duo no services.");
			}
		}
		catch(Exception e)
		{
			_log.error("XMLRPCServer: Error while staring server!", e);
		}
	}

	public static XMLRPCServer getInstance()
	{
		if(_instance == null)
		{
			_instance = new XMLRPCServer();
		}
		return _instance;
	}

	private boolean isAuthenticated(String pUserName, String pPassword) {
		return Config.XML_RPC_LOGIN.equals(pUserName) && Config.XML_RPC_PASSWORD.equals(pPassword);
	}
}