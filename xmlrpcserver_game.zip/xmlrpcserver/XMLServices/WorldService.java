package org.mmocore.xmlrpcserver.XMLServices;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import org.apache.commons.lang3.StringUtils;
import org.mmocore.gameserver.Config;
import org.mmocore.gameserver.cache.CrestCache;
import org.mmocore.gameserver.data.xml.holder.ResidenceHolder;
import org.mmocore.gameserver.instancemanager.OlympiadHistoryManager;
import org.mmocore.gameserver.model.entity.Hero;
import org.mmocore.gameserver.model.entity.olympiad.Olympiad;
import org.mmocore.gameserver.model.entity.residence.Castle;
import org.mmocore.gameserver.model.entity.residence.Dominion;
import org.mmocore.gameserver.tables.CharTemplateTable;
import org.mmocore.gameserver.tables.ClanTable;
import org.mmocore.gameserver.database.DatabaseFactory;
import org.mmocore.gameserver.model.GameObjectsStorage;
import org.mmocore.commons.dbutils.DbUtils;
import org.mmocore.gameserver.templates.StatsSet;
import org.mmocore.gameserver.utils.DDSReader;
import org.mmocore.xmlrpcserver.model.Message;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class WorldService extends Base
{

	private final static String TOPPLAYER_SET = "SELECT c.char_name, cl.class_id, c.pvpkills, c.pkkills, cl.level, ifnull(round(sum(it.count)/1000000),0) FROM characters c join character_subclasses cl on cl.char_obj_id=c.obj_id left join items it on it.owner_id=c.obj_id and it.item_id = 57 where cl.isBase=1 and c.accesslevel=0 and c.account_name not like '~%' GROUP BY c.char_name, cl.class_id, c.pvpkills, c.pkkills, cl.level";

	private final static String QUERRY_TOPLEVEL = TOPPLAYER_SET + " ORDER BY cl.exp DESC LIMIT 0, ?";
	private final static String QUERRY_TOPADENA = TOPPLAYER_SET + " ORDER BY sum(it.count) DESC LIMIT 0, ?";
	private final static String QUERRY_TOPPVP = TOPPLAYER_SET + " ORDER BY `pvpkills` DESC LIMIT 0, ?";
	private final static String QUERRY_TOPPK = TOPPLAYER_SET + " ORDER BY `pkkills` DESC LIMIT 0, ?";
	private final static String QUERRY_TOPCLAN = "SELECT cd.clan_id, cd.clan_level, cd.reputation_score, ifnull(al.crest,\"\") ally_crest, ifnull(cd.crest,\"\") clan_crest FROM clan_data cd left join ally_data al on al.ally_id=cd.ally_id ORDER BY cd.clan_level DESC, cd.reputation_score DESC LIMIT 0, ?";
	private final static String QUERRY_BANLIST = "SELECT c.char_name, bans.baned, bans.unban, bans.reason, bans.endban FROM bans join characters c on c.obj_id=bans.obj_id WHERE endban IS NOT NULL AND endban>unix_timestamp() order by endban desc LIMIT 0, ?";
	private final static String QUERRY_PLAYERS = "SELECT count(*) FROM characters";
	private final static String QUERRY_GOLDS = "SELECT sum(count) FROM items where item_id = 4356";

	private final static SimpleDateFormat dataDateFormat = new SimpleDateFormat("HH:mm dd.MM.yyyy");
	/**
	 * Пустой метод для запроса на сервер, чтобы понять, запущен он или нет.
	 */
	public String idle()
	{
		return json(new Message(Message.MessageType.OK));
	}

	/**
	 * @return количество игроков онлайн
	 */
	public String xmlrpcGetOnline()
	{
		return json(String.valueOf((Math.max(0, GameObjectsStorage.getPlayers().size()) * Config.FAKE_PLAYERS_PERCENT) / 100));
	}

	/**
	 * @return количество игроков
	 */
	public String xmlrpcGetPlayers()
	{
		int count = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_PLAYERS);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				count  = resultSet.getInt(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(String.valueOf(Math.max(0, count)));
	}

	/**
	 * @return количество голды
	 */
	public String xmlrpcGetGoldAmount()
	{
		int count = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_GOLDS);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				count  = resultSet.getInt(1);
			}
		}
		catch(Exception e)
		{
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(String.valueOf(Math.max(0, count)));
	}

	/**
	 * @return сериализованные инстансы игроков онлайн
	 */
	/*public String getAllOnlinePlayersInfo()
	{
		StringBuilder result = new StringBuilder();
		result.append("");
		result.append("<charlist>");
		for(Player pc : GameObjectsStorage.getPlayers())
		{
			if(pc.isVisible())
			{
				result.append(XMLUtils.serializePlayer(pc, false));
			}
		}
		result.append("</charlist>");
		return json(result);
	}*/

	public class TopPlayer{

		private String name, clazz, pvp, pk, level, adena;

		public TopPlayer(String name, String clazz, String pvp, String pk, String level, String adena){
			this.name=name;
			this.clazz=clazz;
			this.pvp=pvp;
			this.pk=pk;
			this.level=level;
			this.adena=adena;
		}
	}

	public class HeroPlayer{

		private String name, clazz, matches, wins;

		public HeroPlayer(String name, String clazz, String matches, String wins){
			this.name=name;
			this.clazz=clazz;
			this.matches=matches;
			this.wins=wins;
		}
	}

	public String xmlrpcTopPK(int count)
	{
		List<TopPlayer> players = new ArrayList<TopPlayer>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_TOPPK);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				String clazz = CharTemplateTable.getClassNameById(Integer.parseInt(resultSet.getString(2)));
				players.add(new TopPlayer(resultSet.getString(1), clazz, resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(players);
	}

	public String xmlrpcTopPvP(int count)
	{
		List<TopPlayer> players = new ArrayList<TopPlayer>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_TOPPVP);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				String clazz = CharTemplateTable.getClassNameById(Integer.parseInt(resultSet.getString(2)));
				players.add(new TopPlayer(resultSet.getString(1), clazz, resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(players);
	}

	public String xmlrpcTopLevel(int count)
	{
		List<TopPlayer> players = new ArrayList<TopPlayer>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_TOPLEVEL);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				String clazz = CharTemplateTable.getClassNameById(Integer.parseInt(resultSet.getString(2)));
				players.add(new TopPlayer(resultSet.getString(1), clazz, resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(players);
	}

	public String xmlrpcTopAdena(int count)
	{
		List<TopPlayer> players = new ArrayList<TopPlayer>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_TOPADENA);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				String clazz = CharTemplateTable.getClassNameById(Integer.parseInt(resultSet.getString(2)));
				players.add(new TopPlayer(resultSet.getString(1), clazz, resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(players);
	}

	public String xmlrpcHeroes()
	{
		List<HeroPlayer> players = new ArrayList<HeroPlayer>();
		Map<Integer, StatsSet> heroes = Hero.getInstance().getAllHeroes();
		if(heroes == null)
			return null;

		for(StatsSet hero : heroes.values())
		{
			int[] stat = OlympiadHistoryManager.getInstance().getMatchStat(hero.getInteger(Olympiad.CHAR_ID));
			String clazz = CharTemplateTable.getClassNameById(hero.getInteger(Olympiad.CLASS_ID));
			players.add(new HeroPlayer(hero.getString(Olympiad.CHAR_NAME), clazz, String.valueOf(stat[0]), String.valueOf(stat[1])));
		}

		return json(players);
	}

	public String getTopClan(int count)
	{
		List<TopClan> clans = new ArrayList<TopClan>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_TOPCLAN);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				int clandId = resultSet.getInt(1);
				String clanLevel = resultSet.getString(2);
				String reputationScore = resultSet.getString(3);
				byte[] allyCrest = resultSet.getBytes(4);
				byte[] clanCrest = resultSet.getBytes(5);
				clans.add(new TopClan(ClanTable.getInstance().getClan(clandId).getName(), String.valueOf(ClanTable.getInstance().getClan(clandId).getAllSize()), reputationScore, ClanTable.getInstance().getClan(clandId).getLeaderName(), clanLevel, allyCrest.length==0? "": Base64.encode(DDSReader.convertToPng(allyCrest, 8, 12)), clanCrest.length==0? "": Base64.encode(DDSReader.convertToPng(clanCrest, 16, 12))));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(clans);
	}

	public String getCastle()
	{
		String name, ownerName, nextSiege, nextWar;

		List<Castle> castles = ResidenceHolder.getInstance().getResidenceList(Castle.class);
		List<CastleInfo> _infos = new ArrayList<CastleInfo>(castles.size());
		for(Castle castle : castles)
		{
			ownerName = ClanTable.getInstance().getClanName(castle.getOwnerId());
			name = castle.getName();
			nextSiege = castle.getSiegeDate().getTimeInMillis()==0? "Unknown" : String.valueOf(dataDateFormat.format(new Date(castle.getSiegeDate().getTimeInMillis())));
			Dominion dominion = ResidenceHolder.getInstance().getResidence(Dominion.class, castle.getId()+80);
			nextWar = dominion.getSiegeDate().getTimeInMillis()==0? "Unknown" : String.valueOf(dataDateFormat.format(new Date(dominion.getSiegeDate().getTimeInMillis())));
			byte[] allyCrest = castle.getOwnerId()==0? null : ClanTable.getInstance().getClan(castle.getOwnerId()).getAlliance() == null? null : CrestCache.getInstance().getAllyCrest(ClanTable.getInstance().getClan(castle.getOwnerId()).getAlliance().getAllyCrestId());
			byte[] clanCrest = castle.getOwnerId()==0? null : CrestCache.getInstance().getPledgeCrest(ClanTable.getInstance().getClan(castle.getOwnerId()).getCrestId());

			_infos.add(new CastleInfo(name, ownerName == StringUtils.EMPTY ? "NPC" : ownerName, nextSiege, nextWar, dominion.getFlags(), allyCrest == null ? "": Base64.encode(DDSReader.convertToPng(allyCrest, 8, 12)), clanCrest == null ? "": Base64.encode(DDSReader.convertToPng(clanCrest, 16, 12))));
		}

		return json(_infos);
	}

	public String getBanList(int count)
	{
		List<BannedPlayer> bans = new ArrayList<BannedPlayer>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = DatabaseFactory.getInstance().getConnection();
			preparedStatement = connection.prepareStatement(QUERRY_BANLIST);
			preparedStatement.setInt(1, count);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				int end = resultSet.getInt(5);
				bans.add(new BannedPlayer(resultSet.getString(1), resultSet.getString(2), end<Integer.MAX_VALUE? resultSet.getString(3): "Permanent", resultSet.getString(4)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(connection, preparedStatement, resultSet);
		}
		return json(bans);
	}

	public class TopClan
	{
		private String name, count, rep, liderName, lvl, allyCrest, clanCrest;

		public TopClan(String name, String count, String rep, String liderName, String lvl, String allyCrest, String clanCrest)
		{
			this.name = name;
			this.count = count;
			this.rep = rep;
			this.liderName = liderName;
			this.lvl = lvl;
			this.allyCrest = allyCrest;
			this.clanCrest = clanCrest;
		}
	}

	public class CastleInfo
	{
		private String name, owner, siege_date, tw_date, allyCrest, clanCrest;
		private List<String> wards = new ArrayList<String>();

		public CastleInfo(String name, String owner, String siege_date, String tw_date, int[] wards, String allyCrest, String clanCrest)
		{
			this.name = name;
			this.owner = owner;
			this.siege_date = siege_date;
			this.tw_date = tw_date;
			this.allyCrest = allyCrest;
			this.clanCrest = clanCrest;
			for(int ward : wards)
				this.wards.add(String.valueOf(ward-80));
		}
	}

	public class BannedPlayer
	{
		private String name, ban_date, ban_end, reason;

		public BannedPlayer(String name, String ban_date, String ban_end, String reason)
		{
			this.name = name;
			this.ban_date = ban_date;
			this.ban_end = ban_end;
			this.reason = reason;
		}
	}
}