package org.mmocore.xmlrpcserver.XMLServices;

import com.google.gson.Gson;
import org.mmocore.commons.dbutils.DbUtils;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

abstract class Base
{
	protected final static Logger logDonate = LoggerFactory.getLogger("donate");

	protected final Gson jsonObject;
	protected Connection conn;
	protected PreparedStatement statement;
	protected ResultSet resultSet;

	public Base()
	{
		jsonObject = new Gson();
	}

	protected void databaseClose(boolean closeResultSet)
	{
		if(closeResultSet)
		{
			DbUtils.closeQuietly(conn, statement, resultSet);
		}
		else
		{
			DbUtils.closeQuietly(conn, statement);
		}
	}

	public <T> String json(T data)
	{
		return jsonObject.toJson(data);
	}
}