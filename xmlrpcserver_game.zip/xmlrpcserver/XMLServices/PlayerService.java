package org.mmocore.xmlrpcserver.XMLServices;

import org.mmocore.commons.dbutils.DbUtils;
import org.mmocore.gameserver.Config;
import org.mmocore.gameserver.dao.AccountBonusDAO;
import org.mmocore.gameserver.dao.CharacterDAO;
import org.mmocore.gameserver.dao.CharacterVariablesDAO;
import org.mmocore.gameserver.dao.ItemsDAO;
import org.mmocore.gameserver.database.DatabaseFactory;
import org.mmocore.gameserver.model.GameObjectsStorage;
import org.mmocore.gameserver.model.Player;
import org.mmocore.gameserver.model.World;
import org.mmocore.gameserver.model.actor.instances.player.Bonus;
import org.mmocore.gameserver.model.items.ItemInstance;
import org.mmocore.gameserver.network.authcomm.AuthServerCommunication;
import org.mmocore.gameserver.network.authcomm.gs2as.BonusRequest;
import org.mmocore.gameserver.network.l2.s2c.ExBR_PremiumState;
import org.mmocore.gameserver.network.l2.s2c.SystemMessage;
import org.mmocore.gameserver.tables.CharTemplateTable;
import org.mmocore.gameserver.utils.ItemFunctions;
import org.mmocore.gameserver.utils.Log;
import org.mmocore.xmlrpcserver.model.Message;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javolution.util.FastList;

public class PlayerService extends Base
{
	/**
	 * Добавляет персонажу заданный итем
	 * @param playerId id игрока
	 * @param itemId ID предмета
	 * @param count количество предмета
	 * @return {@code OK} если добавление состоялось удачно, {@code FAIL} если по каким-то причинам добавление не состоялось
	 */
	public String xmlrpcAddItem(int playerId, int itemId, int count)
	{
		ItemInstance item = ItemFunctions.createItem(itemId);
		item.setCount(count);
		try
		{
			if(playerId < 0)
			{
				return json(new Message(Message.MessageType.FAIL));
			}
			Player player = GameObjectsStorage.getPlayer(playerId);
			if(player != null)
			{
				Log.LogItem(player.getName(), Log.ItemLog.Create, item, itemId, item.getCount(), 0L, 0);
				player.getInventory().addItem(item);
				if(!item.isStackable())
					for(long i = 0; i < count - 1; i++)
					{
						item = ItemFunctions.createItem(itemId);
						Log.LogItem(player, Log.ItemLog.Create, item);
						player.getInventory().addItem(item);
					}
				player.sendPacket(SystemMessage.obtainItems(itemId, count, 0));
				logDonate.info("XML RPC Donate: Player " + player.getName() + " donated ItemId: " + itemId + " Count: " + count + " [IP: " + player.getIP() + "]");
				return json(new Message(Message.MessageType.OK));

			}
			else
			{
				String playerName = CharacterDAO.getInstance().getNameByObjectId(playerId);
				if(playerName == null || playerName.isEmpty())
					return json(new Message(Message.MessageType.FAIL));

				if(item.isStackable()) {
					addStackableOffline(playerId, itemId, count);
					Log.LogItem(playerName, Log.ItemLog.Create, item, itemId, item.getCount(), 0L, 0);
				}
				else
					for (long i = 0; i < count; i++) {
						item = ItemFunctions.createItem(itemId);
						item.setCount(count);
						item.setOwnerId(playerId);
						item.setLocation(ItemInstance.ItemLocation.INVENTORY);
						ItemsDAO.getInstance().save(item);
						Log.LogItem(playerName, Log.ItemLog.Create, item, itemId, 1, 0L, 0);
					}

				logDonate.info("XML RPC Donate: Player " + playerName + " donated ItemId: " + itemId + " Count: " + count + " [OFFLINE PLAYER]");
				return json(new Message(Message.MessageType.OK));
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	public void addStackableOffline(int playerId, int itemId, int count)
	{
		int objId = -1;

		try
		{
			Connection con = DatabaseFactory.getInstance().getConnection();
			PreparedStatement statement = con.prepareStatement("SELECT object_id FROM items WHERE item_id="+itemId+" AND owner_id="+playerId+" AND loc='INVENTORY'");
			ResultSet rset = statement.executeQuery();
			if (rset.next())
				objId = rset.getInt("object_id");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

		if (objId == -1)
		{
			ItemInstance item = ItemFunctions.createItem(itemId);
			item.setCount(count);
			item.setOwnerId(playerId);
			item.setLocation(ItemInstance.ItemLocation.INVENTORY);
			ItemsDAO.getInstance().save(item);
		}
		else
		{
			try
			{
				Connection con = DatabaseFactory.getInstance().getConnection();
				PreparedStatement statement = con.prepareStatement("UPDATE items SET count=count+"+count+" WHERE object_id="+objId);
				statement.execute();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * @param account имя аккаунта
	 * @param days количество дней, на которые установить премиум аккаунт
	 * @return результат операции
	 */
	public String addPremiumDaysForPlayer(String account, int days, long type)
	{
		// Все аккаунты в базе в нижнем регистре !!!!!!!!!!!!!!!!!!!!
		account = account.toLowerCase();
		int endPremiumTime=0;
		try
		{
			if(Config.SERVICES_RATE_TYPE == Bonus.NO_BONUS)
			{
				return json(new Message(Message.MessageType.FAIL));
			}
			else
			{
				// Проверяем, есть ли персонаж онлайн
				boolean foundInWorld = false;
				for(Player player : GameObjectsStorage.getPlayers())
				{
					if(player.getAccountName().equals(account))
					{
						int currentPremiumTime = player.getNetConnection().getBonusExpire();
						if(currentPremiumTime < System.currentTimeMillis())
						{
							currentPremiumTime = (int) (System.currentTimeMillis() / 1000L);
						}
						endPremiumTime = currentPremiumTime + (days * 24 * 60 * 60);
						player.stopBonusTask();
						player.getNetConnection().setBonus(type);
						player.getNetConnection().setBonusExpire(endPremiumTime);
						player.startBonusTask();
						player.updatePremiumItems();

						player.sendPacket(new ExBR_PremiumState(player, true));

						long remainingTime = (endPremiumTime - System.currentTimeMillis()) / 1000;
						int dayz = (int) (remainingTime / 86400);
						remainingTime = remainingTime % 86400;
						int hours = (int) (remainingTime / 3600);
						remainingTime = remainingTime % 3600;
						int minutes = (int) (remainingTime / 60);
						foundInWorld = true;
						player.sendMessage("Ваш премиум аккаунт будет активен: " + dayz + " дней, " + hours + " часов, " + minutes + " минут.");
						logDonate.info("XML RPC Donate: Account " + account + " buyed premium for [DaysAdd: " + days + " PremiumTime: day " + dayz + " hours " + hours + " minutes " + minutes + "]   [IP: " + player.getIP() + "]");
						break;
					}
				}
				// Если персонажа с таким аккаунтом не найдено в игре
				switch(Config.SERVICES_RATE_TYPE)
				{
					case Bonus.BONUS_GLOBAL_ON_AUTHSERVER:
						AuthServerCommunication.getInstance().sendPacket(new BonusRequest(account, type, endPremiumTime));
						break;
					case Bonus.BONUS_GLOBAL_ON_GAMESERVER:
						AccountBonusDAO.getInstance().insert(account, type, endPremiumTime);
						break;
				}

				if(!foundInWorld)
					logDonate.info("XML RPC Donate: Account " + account + " buyed premium for " + days + " days " + "[OFFLINE PLAYER]");
			}
			return json(new Message(Message.MessageType.OK));
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Устанавливает игроку указанный цвет ника
	 * @param charName имя игрока
	 * @param color цвет в RGB
	 * @return результат операции
	 */
	public String setNameColor(String charName, int color)
	{
		try
		{
			Player player = GameObjectsStorage.getPlayer(charName);
			if(player == null)
			{
				if(color != Config.NORMAL_NAME_COLOUR && color != Config.CLANLEADER_NAME_COLOUR && color != Config.GM_NAME_COLOUR && color != Config.SERVICES_OFFLINE_TRADE_NAME_COLOR)
					CharacterVariablesDAO.getInstance().setVar(CharacterDAO.getInstance().getObjectIdByName(charName), "namecolor", Integer.toHexString(color), -1);
				else if(color == Config.NORMAL_NAME_COLOUR)
					CharacterVariablesDAO.getInstance().deleteVar(CharacterDAO.getInstance().getObjectIdByName(charName),"namecolor");
				logDonate.info("XML RPC Donate: Player " + charName + " changed name color to " + Integer.toHexString(color) + " RGB" + " [OFFLINE PLAYER]");
				return json(new Message(Message.MessageType.OK));
			}
			else
			{
				player.setNameColor(color);
				player.broadcastUserInfo(true);
				logDonate.info("XML RPC Donate: Player " + charName + " changed name color to " + Integer.toHexString(color) + " RGB" + " [IP: " + player.getIP() + "]");
				return json(new Message(Message.MessageType.OK));
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Устанавливает игроку указанный цвет титула
	 * @param charName имя игрока
	 * @param color цвет в RGB
	 * @return результат операции
	 */
	public String setTitleColor(String charName, int color)
	{
		try
		{
			Player player = GameObjectsStorage.getPlayer(charName);
			if(player == null)
			{
				if(color != 0xFFFF77)
					CharacterVariablesDAO.getInstance().setVar(CharacterDAO.getInstance().getObjectIdByName(charName), "titlecolor", Integer.toHexString(color), -1);
				else
					CharacterVariablesDAO.getInstance().deleteVar(CharacterDAO.getInstance().getObjectIdByName(charName),"titlecolor");
				logDonate.info("XML RPC Donate: Player " + charName + " title name color to " + Integer.toHexString(color) + " RGB" + " [OFFLINE PLAYER]");
				return json(new Message(Message.MessageType.OK));
			}
			else
			{
				player.setTitleColor(color);
				player.broadcastUserInfo(true);
				logDonate.info("XML RPC Donate: Player " + charName + " changed title color to " + Integer.toHexString(color) + " RGB" + " [IP: " + player.getIP() + "]");
				return json(new Message(Message.MessageType.OK));
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Сброс кармы игрока, если она у него отрицательная
	 * @param charName имя игрока
	 * @return результат операции
	 */
	public String resetKarmaToZero(String charName)
	{
		try
		{
			Player player = GameObjectsStorage.getPlayer(charName);
			if(player == null)
			{
				int karma = 0;
				int objectId = CharacterDAO.getInstance().getObjectIdByName(charName);
				if(objectId == 0){
					databaseClose(true);
					return json(new Message(Message.MessageType.FAIL));
				}

				conn = DatabaseFactory.getInstance().getConnection();
				statement = conn.prepareStatement("SELECT karma FROM characters WHERE obj_id=?");
				statement.setInt(1, objectId);
				resultSet = statement.executeQuery();
				while(resultSet.next())
				{
					karma = resultSet.getInt("karma");
				}

				if(karma > 0)
				{
					statement = conn.prepareStatement("UPDATE characters SET karma=0 WHERE obj_id=?");
					statement.setInt(1, objectId);
					statement.execute();
					databaseClose(true);
					return json(new Message(Message.MessageType.OK));
				}
				else
				{
					databaseClose(true);
					return json(new Message(Message.MessageType.FAIL));
				}
			}
			else
			{
				int karma = player.getKarma();
				if(karma > 0)
				{
					player.setKarma(0, true);
					return json(new Message(Message.MessageType.OK));
				}
				else
				{
					return json(new Message(Message.MessageType.FAIL));
				}
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Возвращает всех персонажей с заданным аккаунтом
	 * @param account имя аккаунта
	 * @return сериализованные инстансы игроков на аккаунте
	 */
	public String getAllCharsFromAccount(String account)
	{
		List<SitePlayer> result = new ArrayList<SitePlayer>();
		try
		{
			conn = DatabaseFactory.getInstance().getConnection();
			statement = conn.prepareStatement("SELECT c.obj_id, c.char_name, sub.class_id, sub.level, c.pvpkills, c.pkkills, c.karma, c.lastaccess, c.hwid_lock FROM characters c " +
					"join character_subclasses sub on sub.char_obj_id = c.obj_id and sub.isBase = 1 " +
					"WHERE account_name=? LIMIT 7");
			statement.setString(1, account);
			resultSet = statement.executeQuery();
			SitePlayer pc;
			while(resultSet.next())
			{

				pc = new SitePlayer(resultSet.getString(1), resultSet.getString(2), CharTemplateTable.getClassNameById(Integer.parseInt(resultSet.getString(3))), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8), resultSet.getString(9)!=null? "true" : "false");//Util.loadPlayer(resultSet.getString(1), true);
				if(pc != null)
				{
					result.add(pc);
				}
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
		finally
		{
			databaseClose(true);
		}
		return json(result);
	}

	/**
	 * Разблокировка аккаунта.
	 */
	public String resetLock(String account, int objId)
	{
		if(World.getPlayer(objId) == null)
		{
			Connection con = null;
			PreparedStatement statement = null;
			ResultSet rs = null;
			try
			{
				con = DatabaseFactory.getInstance().getConnection();
				statement = con.prepareStatement("SELECT account_name FROM characters WHERE obj_Id=?");
				statement.setInt(1, objId);
				statement.execute();
				rs = statement.getResultSet();
				rs.next();

				String account_name = rs.getString("account_name");

				DbUtils.close(statement, rs);

				if(!account_name.equalsIgnoreCase(account))
					return json(new Message(Message.MessageType.FAIL));

				statement = con.prepareStatement("UPDATE characters SET hwid_lock=NULL WHERE obj_Id=?");
				statement.setInt(1, objId);
				statement.execute();
				DbUtils.close(statement);
			}
			catch(Exception e)
			{
				Log.add(getClass().getSimpleName() + ": Error while ResetLock() : ", "Error");
				return json(new Message(Message.MessageType.FAIL));
			}
			finally
			{
				DbUtils.closeQuietly(con, statement, rs);
			}
		}
		else
		{
			return json(new Message(Message.MessageType.FAIL));
		}

		return json(new Message(Message.MessageType.OK));
	}

	/**
	 * Возвращает список имен персонажей аккаунта.
	 * @param account имя аккаунта
	 * @return игроков на аккаунте
	 */
	public String xmlrpcGetPlayerNamesByAccount(String account)
	{
		List<String> names = new FastList<String>();
		try
		{
			conn = DatabaseFactory.getInstance().getConnection();
			statement = conn.prepareStatement("SELECT char_name FROM characters WHERE account_name=?");
			statement.setString(1, account);
			resultSet = statement.executeQuery();
			while(resultSet.next())
			{
				names.add(resultSet.getString(1));
			}
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
		finally
		{
			databaseClose(true);
		}

		return json(names);
	}

	/**
	 * Сериализует персонажа с указанным именем
	 * @param charName имя персонажа
	 * @param full режим сериализации
	 * @return сериализованный инстанс игрока
	 */
	/*public String getPlayer(String charName, String full)
	{
		L2PcInstance pc;
		String result = "";
		if(WorldManager.getInstance().getPlayer(charName) == null)
		{
			pc = Util.loadPlayer(charName, true);
		}
		else
		{
			pc = WorldManager.getInstance().getPlayer(charName);
		}

		try
		{
			if(pc != null)
			{
				result += XMLUtils.serializePlayer(pc, Boolean.parseBoolean(full));
			}
			else
			{
				result += "<char/>";
			}
		}
		catch(Exception e)
		{
			log.log(Level.ERROR, getClass().getSimpleName() + ": Error while getPlayer() : ", e);
		}
		finally
		{
			try
			{
				pc.getLocationController().delete();
			}
			catch(NullPointerException e)
			{
				log.log(Level.ERROR, getClass().getSimpleName() + ": NPE Error while getPlayer().deleteMe() : ", e);
			}
		}

		return json(result);
	}*/

	/**
	 * Восстановление игрока в ближайший город
	 * @param objId id игрока
	 * @return результат
	 */
	public String unstuckPlayer(String account, int objId)
	{
		if(World.getPlayer(objId) == null)
		{
			Connection con = null;
			PreparedStatement statement = null;
			ResultSet rs = null;
			try
			{
				con = DatabaseFactory.getInstance().getConnection();
				statement = con.prepareStatement("SELECT account_name, karma FROM characters WHERE obj_Id=?");
				statement.setInt(1, objId);
				statement.execute();
				rs = statement.getResultSet();
				rs.next();

				String account_name = rs.getString("account_name");
				int karma = rs.getInt("karma");

				DbUtils.close(statement, rs);

				if(!account_name.equalsIgnoreCase(account))
					return json(new Message(Message.MessageType.FAIL));

				if(karma > 0)
				{
					statement = con.prepareStatement("UPDATE characters SET x=17144, y=170156, z=-3502 WHERE obj_Id=?");
					statement.setInt(1, objId);
					statement.execute();
					DbUtils.close(statement);
				}
				else
				{
					statement = con.prepareStatement("UPDATE characters SET x=0, y=0, z=0 WHERE obj_Id=?");
					statement.setInt(1, objId);
					statement.execute();
					DbUtils.close(statement);
				}

				statement = con.prepareStatement("DELETE FROM character_variables WHERE obj_id=? AND type='user-var' AND name='reflection'");
				statement.setInt(1, objId);
				statement.execute();
				DbUtils.close(statement);
			}
			catch(Exception e)
			{
				Log.add(getClass().getSimpleName() + ": Error while unstuckPlayer() : ", "Error");
				return json(new Message(Message.MessageType.FAIL));
			}
			finally
			{
				DbUtils.closeQuietly(con, statement, rs);
			}
		}
		else
		{
			// Нельзя анстакать игрока, который онлайн
			return json(new Message(Message.MessageType.FAIL));
		}
		return json(new Message(Message.MessageType.OK));
	}

	private class SitePlayer{

		private String id, name, charclass, lastaccess, level, pvp, pk, karma, hwid;

		private SitePlayer(String id,String name, String charclass, String level, String pvp, String pk, String karma, String lastaccess, String hwid)
		{
			this.id = id;
			this.name = name;
			this.charclass = charclass;
			this.level = level;
			this.pvp = pvp;
			this.pk = pk;
			this.karma = karma;
			this.lastaccess = lastaccess;
			this.hwid = hwid;
		}
	}

}