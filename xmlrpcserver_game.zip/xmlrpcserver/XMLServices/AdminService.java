package org.mmocore.xmlrpcserver.XMLServices;

import org.mmocore.gameserver.Config;
import org.mmocore.gameserver.Shutdown;
import org.mmocore.gameserver.dao.CharacterQuestDAO;
import org.mmocore.gameserver.data.htm.HtmCache;
import org.mmocore.gameserver.data.xml.holder.ProductHolder;
import org.mmocore.gameserver.data.xml.parser.ItemParser;
import org.mmocore.gameserver.data.xml.parser.MultiSellParser;
import org.mmocore.gameserver.data.xml.parser.NpcParser;
import org.mmocore.gameserver.model.GameObjectsStorage;
import org.mmocore.gameserver.model.Player;
import org.mmocore.gameserver.model.quest.QuestState;
import org.mmocore.gameserver.tables.SkillTable;
import org.mmocore.xmlrpcserver.model.Message;

public class AdminService extends Base
{
	/**
	 * Перезагрузка указанного инстанса
	 * @param instance инстанс для перезагрузки
	 * @return {@code OK} если перезагрузка удачна, {@code FAIL} если по каким-то причинам случилась ошибка
	 */
	public String reloadInstance(String instance)
	{
		try
		{
			if (instance.equals("config")) {
				Config.load();
			} else if (instance.equals("html")) {
				HtmCache.getInstance().reload();

			} else if (instance.equals("item")) {
				ItemParser.getInstance().reload();

			} else if (instance.equals("multisell")) {
				MultiSellParser.getInstance().reload();

			} else if (instance.equals("npc")) {
				NpcParser.getInstance().reload();

			} else if (instance.equals("quest")) {
				for (Player p : GameObjectsStorage.getPlayers())
					reloadQuestStates(p);

			} else if (instance.equals("skill")) {
				SkillTable.getInstance().reload();

			} else if (instance.equals("primeshop")) {
				ProductHolder.getInstance().reload();

			} else if (instance.equals("access")) {
				Config.loadGMAccess();
				for (Player player : GameObjectsStorage.getPlayers())
					if (!Config.EVERYBODY_HAS_ADMIN_RIGHTS)
						player.setPlayerAccess(Config.gmlist.get(player.getObjectId()));
					else
						player.setPlayerAccess(Config.gmlist.get(new Integer(0)));

			}
			return json(new Message(Message.MessageType.OK));
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Выключение\рестарт сервера
	 * @param restart {@code true} рестартовать сервер после выключения, {@code false} если сервер нужно просто выключить
	 * @return {@code OK} если перезагрузка удачна, {@code FAIL} если по каким-то причинам случилась ошибка
	 */
	public String restartServer(String restart)
	{
		try
		{
			Shutdown.getInstance().schedule(300, Boolean.parseBoolean(restart) ? 2 : 0);
			return json(new Message(Message.MessageType.OK));
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Отмена выключения\перезагрузки сервера
	 * @return {@code OK} если отмена удачна, {@code FAIL} если по каким-то причинам случилась ошибка
	 */
	public String abortRestartServer()
	{
		try
		{
			Shutdown.getInstance().cancel();
			return json(new Message(Message.MessageType.OK));
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	private void reloadQuestStates(Player p)
	{
		for(QuestState qs : p.getAllQuestsStates())
			p.removeQuestState(qs.getQuest().getId());
		CharacterQuestDAO.getInstance().select(p);
	}

}