package org.mmocore.xmlrpcserver;

public class Account
{
	public static final String ACCOUNT_EXISTS = "SELECT COUNT(*) FROM `accounts` WHERE `login` = ? LIMIT 1";
	public static final String ADD_ACCOUNT = "INSERT INTO `accounts` (`login`, `password`) VALUES (?,?)";
	public static final String CHANGE_PASSWORD = "UPDATE `accounts` SET `password` = ? WHERE `login` = ? AND `password` = ?";
	public static final String SET_PASSWORD = "UPDATE `accounts` SET `password` = ? WHERE `login` = ?";
}