package org.mmocore.xmlrpcserver.XMLServices;

import org.mmocore.authserver.database.L2DatabaseFactory;
import org.mmocore.commons.dbutils.DbUtils;
import org.mmocore.xmlrpcserver.model.Message;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class WorldService extends Base
{
	/**
	 * Пустой метод для запроса на сервер, чтобы понять, запущен он или нет.
	 * @return
	 */
	public String idle()
	{
		return json(new Message(Message.MessageType.OK));
	}

	public String getAccountAmount()
	{
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rset = null;

		int count = 0;
		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("SELECT count(*) FROM `accounts`");
			rset = statement.executeQuery();

			if(rset.next())
			{
				count = rset.getInt(1);
			}

			rset.close();
			statement.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return json(new Message(Message.MessageType.FAIL));
		}
		finally
		{
			DbUtils.closeQuietly(con, statement, rset);
		}

		return json(String.valueOf(Math.max(0, count)));
	}

	public String getTopAlerts(int alertListCount)
	{
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rset = null;
		List<Alert> alerts = new ArrayList<Alert>();
		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("SELECT login, alert_points, ban_expire FROM `accounts` order by alert_points desc limit 0,?");
			statement.setInt(1, alertListCount);
			rset = statement.executeQuery();

			while(rset.next())
			{
				alerts.add(new Alert(rset.getString(1), rset.getString(2), rset.getString(3)));
			}

			rset.close();
			statement.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return json(new Message(Message.MessageType.FAIL));
		}
		finally
		{
			DbUtils.closeQuietly(con, statement, rset);
		}
		return json(alerts);
	}

	public class Alert
	{
		private String login, points, ban_expire;

		public Alert(String login, String points, String ban_expire)
		{
			this.login = login;
			this.points = points;
			this.ban_expire = ban_expire;
		}
	}
}