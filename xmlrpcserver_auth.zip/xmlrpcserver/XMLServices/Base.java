package org.mmocore.xmlrpcserver.XMLServices;

import com.google.gson.Gson;

import org.mmocore.commons.dbutils.DbUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

abstract class Base
{
	protected final Gson jsonObject;
	protected Connection conn;
	protected PreparedStatement statement;
	protected ResultSet resultSet;

	protected Base()
	{
		jsonObject = new Gson();
	}

	protected void databaseClose(boolean closeResultSet)
	{
		if(closeResultSet)
		{
			try {

				DbUtils.close(statement, resultSet);
				DbUtils.close(conn);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			try {
				DbUtils.close(statement);
				DbUtils.close(conn);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	protected <T> String json(T data)
	{
		return jsonObject.toJson(data);
	}
}