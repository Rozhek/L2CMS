package org.mmocore.xmlrpcserver.XMLServices;

import org.mmocore.authserver.Config;
import org.mmocore.authserver.database.L2DatabaseFactory;
import org.mmocore.xmlrpcserver.Account;
import org.mmocore.xmlrpcserver.model.Message;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerService extends Base
{
	/**
	 * Checks if user typed correct information for existing account.
	 */
	public String login(String name, String password)
	{
		String hash;

		try
		{
			hash = Config.DEFAULT_CRYPT.encrypt(password);
		}
		catch(Exception e)
		{
			return json(new Message(Message.MessageType.FAIL, "Неверный пароль."));
		}

		Connection con;
		PreparedStatement statement;
		ResultSet rset;

		boolean ok = false;
		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("SELECT * FROM `accounts` WHERE `login` = ? AND `password` = ?");
			statement.setString(1, name);
			statement.setString(2, hash);
			rset = statement.executeQuery();

			if(rset.next())
			{
				ok = true;
			}

			rset.close();
			statement.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return json(new Message(Message.MessageType.FAIL));
		}
		finally
		{
			databaseClose(true);
		}

		if(ok)
		{
			return json(new Message(Message.MessageType.OK));
		}
		else
		{
			return json(new Message(Message.MessageType.FAIL));
		}
	}

	/**
	 * Checks if account with specified name already exists.
	 */
	public String exists(String account)
	{
		boolean exists = false;
		try
		{
			conn = L2DatabaseFactory.getInstance().getConnection();
			statement = conn.prepareStatement(Account.ACCOUNT_EXISTS);
			statement.setString(1, account);
			resultSet = statement.executeQuery();

			if(resultSet.next() && resultSet.getInt(1) > 0)
			{
				exists = true;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			exists = true;
		}
		finally
		{
			databaseClose(true);
		}
		if(exists)
			return json(new Message(Message.MessageType.OK, ""));

		return json(new Message(Message.MessageType.FAIL, ""));
	}

	/**
	 * Registers account.
	 */
	public String xmlrpcRegister(String account, String password)
	{
		boolean ok = true;
		try
		{
			conn = L2DatabaseFactory.getInstance().getConnection();

			// Check if account with same name is exists
			statement = conn.prepareStatement(Account.ACCOUNT_EXISTS);
			statement.setString(1, account);
			resultSet = statement.executeQuery();

			if(resultSet.next() && resultSet.getInt(1) > 0)
			{
				return json(new Message(Message.MessageType.FAIL, "Аккаунт с таким именем уже существует."));
			}

			statement = conn.prepareStatement(Account.ADD_ACCOUNT);
			statement.setString(1, account);
			statement.setString(2, Config.DEFAULT_CRYPT.encrypt(password));
			statement.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ok = false;
		}
		finally
		{
			databaseClose(false);
		}

		if(ok)
		{
			return json(new Message(Message.MessageType.OK));
		}
		else
		{
			return json(new Message(Message.MessageType.FAIL, "Произошла ошибка при работе с базой данных"));
		}
	}

	/**
	 * Смена пароля от аккаунта.
	 */
	public String xmlrpcChangePassword(String account, String oldpass, String password)
	{
		boolean ok = true;
		try
		{
			conn = L2DatabaseFactory.getInstance().getConnection();
			statement = conn.prepareStatement(Account.CHANGE_PASSWORD);
			statement.setString(1, Config.DEFAULT_CRYPT.encrypt(password));
			statement.setString(2, account.toLowerCase());
			statement.setString(3, Config.DEFAULT_CRYPT.encrypt(oldpass));
			if(statement.executeUpdate()==0)
				ok = false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ok = false;
		}
		finally
		{
			databaseClose(false);
		}

		if(ok)
		{
			return json(new Message(Message.MessageType.OK));
		}
		else
		{
			return json(new Message(Message.MessageType.FAIL, "Произошла ошибка при работе с базой данных"));
		}
	}

	/**
	 * Смена пароля от аккаунта.
	 */
	public String xmlrpcSetPassword(String account, String password)
	{
		boolean ok = true;
		try
		{
			conn = L2DatabaseFactory.getInstance().getConnection();
			statement = conn.prepareStatement(Account.SET_PASSWORD);
			statement.setString(1, Config.DEFAULT_CRYPT.encrypt(password));
			statement.setString(2, account.toLowerCase());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ok = false;
		}
		finally
		{
			databaseClose(false);
		}

		if(ok)
		{
			return json(new Message(Message.MessageType.OK));
		}
		else
		{
			return json(new Message(Message.MessageType.FAIL, "Произошла ошибка при работе с базой данных"));
		}
	}

	public String xmlrpcSetAlerts(String login, int points)
	{
		Connection con;
		PreparedStatement statement;
		ResultSet rset;

		boolean ok = false;
		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("update `accounts` SET `alert_points` = ? WHERE `login` = ?");
			statement.setInt(1, points);
			statement.setString(2, login);
			statement.execute();
			statement.close();
			return json(new Message(Message.MessageType.OK));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return json(new Message(Message.MessageType.FAIL));
	}

/*
	public synchronized String checkAccessLevel(String account)
	{
		Connection con;
		PreparedStatement statement;
		ResultSet rset;

		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("SELECT * FROM `accounts` WHERE `login` = ?");
			statement.setString(1, account);
			rset = statement.executeQuery();

			String accessLevel = "0";
			if(rset.next())
			{
				accessLevel = rset.getString("accessLevel");
			}

			rset.close();
			statement.close();

			return json(new Message(Message.MessageType.OK, accessLevel));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return json(new Message(Message.MessageType.FAIL));
	}

	public String setAccessLevel(String account, int accessLevel)
	{
		Connection con;
		PreparedStatement statement;

		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("UPDATE `accounts` SET `accessLevel`=? WHERE `login`=?");
			statement.setInt(1, accessLevel);
			statement.setString(2, account);
			statement.execute();
			statement.close();
			return json(new Message(Message.MessageType.OK));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return json(new Message(Message.MessageType.FAIL));
	}*/
}