package org.mmocore.xmlrpcserver.model;

public class Message
{
	private final MessageType type;
	private final String message;

	public Message(MessageType type)
	{
		this.type = type;
		this.message = "";
	}

	public Message(MessageType type, String message)
	{
		this.type = type;
		this.message = message;
	}

	public enum MessageType
	{
		OK,
		FAIL
	}
}